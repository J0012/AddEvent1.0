package com.example.addevent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HomeworkPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homework_page);
    }
}